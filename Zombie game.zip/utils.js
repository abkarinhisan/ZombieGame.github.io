// Small shared helpers + world constants.
const WORLD = { w: 2400, h: 1600 };

const Utils = {
  clamp: (v, lo, hi) => Math.max(lo, Math.min(hi, v)),
  dist: (a, b) => Math.hypot(a.x - b.x, a.y - b.y),
  rand: (lo, hi) => lo + Math.random() * (hi - lo),

  // Push a circle entity (x, y, radius) out of an axis-aligned rectangle.
  pushOutOfRect(e, r) {
    const cx = Utils.clamp(e.x, r.x, r.x + r.w);
    const cy = Utils.clamp(e.y, r.y, r.y + r.h);
    let dx = e.x - cx, dy = e.y - cy, d = Math.hypot(dx, dy);
    if (d >= e.radius) return;
    if (d === 0) { dx = 1; dy = 0; d = 1; }
    const push = e.radius - d;
    e.x += (dx / d) * push;
    e.y += (dy / d) * push;
  },
  pointInRect: (x, y, r) => x > r.x && x < r.x + r.w && y > r.y && y < r.y + r.h,
};
