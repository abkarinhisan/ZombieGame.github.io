// HUD + overlay screens (canvas-drawn for now; Phase 7 builds full menus).
const UIManager = {
  drawHUD(ctx, game) {
    const p = game.player, w = p.weapon;
    ctx.font = '600 18px "Trebuchet MS", sans-serif'; ctx.textBaseline = 'top';
    ctx.fillStyle = '#000a'; ctx.fillRect(14, 14, 250, 118);
    ctx.fillStyle = '#e8e4d8';
    ctx.fillText('❤️ Health', 26, 24);
    ctx.fillStyle = '#3a1512'; ctx.fillRect(130, 28, 120, 12);
    ctx.fillStyle = '#d9483b'; ctx.fillRect(130, 28, 120 * p.health / p.maxHealth, 12);
    ctx.fillStyle = '#e8e4d8';
    ctx.fillText('🔫 ' + w.def.name, 26, 54);
    ctx.fillText('🔢 ' + (w.isReloading ? 'Reloading…' : `${w.ammo} / ${w.def.magSize}`), 26, 82);
    ctx.fillText('🧟 Zombies: ' + game.zombies.length, 26, 106);
  },
  drawGameOver(ctx, W, H) {
    ctx.fillStyle = '#000b'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#d9483b'; ctx.font = '700 64px Georgia, serif'; ctx.textAlign = 'center';
    ctx.fillText('YOU WERE OVERRUN', W / 2, H / 2 - 50);
    ctx.fillStyle = '#e8e4d8'; ctx.font = '22px "Trebuchet MS", sans-serif';
    ctx.fillText('Press Enter to restart', W / 2, H / 2 + 30);
    ctx.textAlign = 'left';
  },
};
