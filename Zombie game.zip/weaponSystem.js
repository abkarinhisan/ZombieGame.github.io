// Weapon data + per-weapon state (ammo, cooldown, reload). Phase 5 adds rifle/shotgun here.
const WEAPONS = {
  pistol: {
    name: 'Pistol', damage: 25, fireRate: 3.5, // shots per second
    magSize: 12, reloadTime: 1.2, range: 600, bulletSpeed: 900, pellets: 1, spread: 0.02,
  },
};

class WeaponSystem {
  constructor(id) {
    this.def = WEAPONS[id];
    this.ammo = this.def.magSize;
    this.cooldown = 0;
    this.reloadLeft = 0;
  }
  get isReloading() { return this.reloadLeft > 0; }

  update(dt) {
    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.isReloading) {
      this.reloadLeft -= dt;
      if (this.reloadLeft <= 0) { this.reloadLeft = 0; this.ammo = this.def.magSize; }
    }
  }

  startReload() {
    // Edge cases: already full, or already reloading -> ignore.
    if (this.isReloading || this.ammo >= this.def.magSize) return;
    this.reloadLeft = this.def.reloadTime;
  }

  // Returns an array of new bullets (empty if the weapon could not fire).
  tryShoot(x, y, angle) {
    if (this.isReloading || this.cooldown > 0) return [];
    if (this.ammo <= 0) { this.startReload(); return []; } // dry fire -> auto reload
    this.ammo--;
    this.cooldown = 1 / this.def.fireRate;
    const bullets = [];
    for (let i = 0; i < this.def.pellets; i++) {
      const a = angle + Utils.rand(-this.def.spread, this.def.spread);
      bullets.push({
        x, y, vx: Math.cos(a) * this.def.bulletSpeed, vy: Math.sin(a) * this.def.bulletSpeed,
        damage: this.def.damage, range: this.def.range, travelled: 0, dead: false,
      });
    }
    if (this.ammo === 0) this.startReload();
    return bullets;
  }
}
