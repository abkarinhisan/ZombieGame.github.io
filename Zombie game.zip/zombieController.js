// Zombie: chase target, attack when close, take damage, die. Phase 4 adds more types.
const ZOMBIE_TYPES = {
  normal: { health: 60, speed: 60, damage: 10, attackRate: 1.0, radius: 15, color: '#6f8f4a', reward: 10 },
};

class ZombieController {
  constructor(type, x, y) {
    this.def = ZOMBIE_TYPES[type];
    this.x = x; this.y = y; this.radius = this.def.radius;
    this.health = this.def.health; this.maxHealth = this.def.health;
    this.attackCooldown = 0; this.hitFlash = 0; this.angle = 0;
    this.dead = false;
  }

  update(dt, target, obstacles) {
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.hitFlash = Math.max(0, this.hitFlash - dt);
    const dx = target.x - this.x, dy = target.y - this.y, d = Math.hypot(dx, dy);
    this.angle = Math.atan2(dy, dx);
    const reach = this.radius + target.radius + 4;

    if (d > reach) {                       // chase
      this.x += (dx / d) * this.def.speed * dt;
      this.y += (dy / d) * this.def.speed * dt;
      obstacles.forEach(o => Utils.pushOutOfRect(this, o)); // slide around obstacles
    } else if (this.attackCooldown <= 0) { // stop and attack
      target.takeDamage(this.def.damage);
      this.attackCooldown = 1 / this.def.attackRate;
    }
  }

  takeDamage(amount) {
    if (this.dead) return false;
    this.health -= amount; this.hitFlash = 0.1;
    if (this.health <= 0) this.dead = true;
    return this.dead;
  }

  draw(ctx) {
    ctx.save(); ctx.translate(this.x, this.y);
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.beginPath(); ctx.ellipse(3, 5, this.radius, this.radius * .8, 0, 0, 7); ctx.fill();
    ctx.rotate(this.angle);
    ctx.fillStyle = this.hitFlash > 0 ? '#fff' : this.def.color;
    ctx.fillRect(6, -12, 14, 6); ctx.fillRect(6, 6, 14, 6);            // reaching arms
    ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, 7); ctx.fill();
    ctx.fillStyle = '#a32020'; ctx.fillRect(7, -5, 3, 3); ctx.fillRect(7, 2, 3, 3); // eyes
    ctx.restore();
    if (this.health < this.maxHealth) {                                  // health bar
      ctx.fillStyle = '#000a'; ctx.fillRect(this.x - 16, this.y - this.radius - 12, 32, 5);
      ctx.fillStyle = '#c0392b'; ctx.fillRect(this.x - 16, this.y - this.radius - 12, 32 * this.health / this.maxHealth, 5);
    }
  }
}
