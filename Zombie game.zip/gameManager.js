// GameManager: owns the loop, world, camera, bullets, zombies and rendering.
class GameManager {
  constructor(canvas) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d');
    this.resize(); window.addEventListener('resize', () => this.resize());
    Input.init(canvas);
    this.buildWorld();
    this.reset();
    this.last = performance.now();
    requestAnimationFrame(t => this.loop(t));
  }
  resize() { this.canvas.width = innerWidth; this.canvas.height = innerHeight; }

  // Static scenery. All are solid rectangles that block player, zombies and bullets.
  buildWorld() {
    this.obstacles = [
      { x: 1050, y: 700, w: 300, h: 24, type: 'sandbag' }, { x: 1050, y: 900, w: 300, h: 24, type: 'sandbag' },
      { x: 1050, y: 724, w: 24, h: 60, type: 'sandbag' },   { x: 1050, y: 840, w: 24, h: 60, type: 'sandbag' },
      { x: 1326, y: 724, w: 24, h: 60, type: 'sandbag' },   { x: 1326, y: 840, w: 24, h: 60, type: 'sandbag' },
      { x: 700, y: 500, w: 50, h: 50, type: 'crate' },  { x: 760, y: 520, w: 40, h: 40, type: 'crate' },
      { x: 1600, y: 1100, w: 50, h: 50, type: 'crate' }, { x: 500, y: 1150, w: 220, h: 90, type: 'car' },
      { x: 1700, y: 400, w: 180, h: 120, type: 'building' },
    ];
  }

  reset() {
    this.player = new PlayerController(WORLD.w / 2, WORLD.h / 2);
    this.zombies = []; this.bullets = []; this.respawnTimer = 1;
    this.state = 'playing'; this.cam = { x: 0, y: 0 };
  }

  // Phase 1 test spawner: one zombie at a time, just off-screen. Phase 2 replaces this with waves.
  spawnZombie() {
    const a = Math.random() * Math.PI * 2, r = Math.hypot(this.canvas.width, this.canvas.height) / 2 + 80;
    this.zombies.push(new ZombieController('normal',
      Utils.clamp(this.player.x + Math.cos(a) * r, 20, WORLD.w - 20),
      Utils.clamp(this.player.y + Math.sin(a) * r, 20, WORLD.h - 20)));
  }

  loop(now) {
    const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now;
    this.update(dt); this.draw(); Input.endFrame();
    requestAnimationFrame(t => this.loop(t));
  }

  update(dt) {
    if (this.state === 'gameover') { if (Input.wasPressed('Enter')) this.reset(); return; }
    const W = this.canvas.width, H = this.canvas.height, p = this.player;
    this.cam.x = Utils.clamp(p.x - W / 2, 0, Math.max(0, WORLD.w - W));
    this.cam.y = Utils.clamp(p.y - H / 2, 0, Math.max(0, WORLD.h - H));
    const mouseWorld = { x: Input.mouse.x + this.cam.x, y: Input.mouse.y + this.cam.y };

    p.update(dt, mouseWorld, this.obstacles, this.bullets);

    if (this.zombies.length === 0 && (this.respawnTimer -= dt) <= 0) { this.spawnZombie(); this.respawnTimer = 2; }
    this.zombies.forEach(z => z.update(dt, p, this.obstacles));

    // Bullets: move, hit walls, hit zombies
    for (const b of this.bullets) {
      b.x += b.vx * dt; b.y += b.vy * dt; b.travelled += b.speed || Math.hypot(b.vx, b.vy) * dt;
      if (b.travelled > b.range || this.obstacles.some(o => Utils.pointInRect(b.x, b.y, o))) { b.dead = true; continue; }
      for (const z of this.zombies) {
        if (!z.dead && Math.hypot(z.x - b.x, z.y - b.y) < z.radius) { z.takeDamage(b.damage); b.dead = true; break; }
      }
    }
    this.bullets = this.bullets.filter(b => !b.dead);
    this.zombies = this.zombies.filter(z => !z.dead); // handles several zombies dying in the same frame

    if (p.dead) this.state = 'gameover';
  }

  draw() {
    const ctx = this.ctx, W = this.canvas.width, H = this.canvas.height;
    ctx.fillStyle = '#1a1d19'; ctx.fillRect(0, 0, W, H);
    ctx.save(); ctx.translate(-this.cam.x, -this.cam.y);
    // Cracked-asphalt grid
    ctx.strokeStyle = '#242823'; ctx.lineWidth = 2; ctx.beginPath();
    for (let x = 0; x <= WORLD.w; x += 100) { ctx.moveTo(x, 0); ctx.lineTo(x, WORLD.h); }
    for (let y = 0; y <= WORLD.h; y += 100) { ctx.moveTo(0, y); ctx.lineTo(WORLD.w, y); }
    ctx.stroke();
    ctx.strokeStyle = '#6b2a24'; ctx.lineWidth = 6; ctx.strokeRect(0, 0, WORLD.w, WORLD.h); // world edge

    const colors = { sandbag: '#8c7a55', crate: '#6e4b2a', car: '#4a5560', building: '#33302d' };
    for (const o of this.obstacles) {
      ctx.fillStyle = colors[o.type]; ctx.fillRect(o.x, o.y, o.w, o.h);
      ctx.strokeStyle = '#0006'; ctx.lineWidth = 3; ctx.strokeRect(o.x, o.y, o.w, o.h);
    }
    this.zombies.forEach(z => z.draw(ctx));
    this.player.draw(ctx);
    ctx.fillStyle = '#ffd35a';
    for (const b of this.bullets) ctx.fillRect(b.x - 3, b.y - 3, 6, 6);
    ctx.restore();

    // Dark vignette for atmosphere
    const g = ctx.createRadialGradient(W / 2, H / 2, H * .3, W / 2, H / 2, Math.max(W, H) * .7);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.65)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    UIManager.drawHUD(ctx, this);
    if (this.state === 'gameover') UIManager.drawGameOver(ctx, W, H);
  }
}
window.addEventListener('load', () => new GameManager(document.getElementById('game')));
