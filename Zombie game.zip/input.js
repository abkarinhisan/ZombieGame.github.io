// Keyboard + mouse state. "pressed" values last one frame (call Input.endFrame()).
const Input = {
  keys: {}, pressed: {}, mouse: { x: 0, y: 0, down: false },

  init(canvas) {
    window.addEventListener('keydown', e => {
      if (!this.keys[e.code]) this.pressed[e.code] = true;
      this.keys[e.code] = true;
    });
    window.addEventListener('keyup', e => { this.keys[e.code] = false; });
    window.addEventListener('blur', () => { this.keys = {}; this.mouse.down = false; });
    canvas.addEventListener('mousemove', e => { this.mouse.x = e.offsetX; this.mouse.y = e.offsetY; });
    canvas.addEventListener('mousedown', e => { if (e.button === 0) this.mouse.down = true; });
    window.addEventListener('mouseup', e => { if (e.button === 0) this.mouse.down = false; });
    canvas.addEventListener('contextmenu', e => e.preventDefault());
  },
  isDown: code => !!Input.keys[code],
  wasPressed: code => !!Input.pressed[code],
  endFrame() { this.pressed = {}; },
};
