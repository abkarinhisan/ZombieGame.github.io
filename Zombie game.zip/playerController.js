// Player: movement, aiming, health, shooting via WeaponSystem.
class PlayerController {
  constructor(x, y) {
    this.x = x; this.y = y; this.radius = 16;
    this.speed = 190; this.sprintMult = 1.6;
    this.maxHealth = 100; this.health = 100;
    this.angle = 0;
    this.weapon = new WeaponSystem('pistol');
    this.hurtFlash = 0;
  }
  get dead() { return this.health <= 0; }

  update(dt, mouseWorld, obstacles, bullets) {
    // Movement (normalised so diagonals aren't faster)
    let dx = (Input.isDown('KeyD') ? 1 : 0) - (Input.isDown('KeyA') ? 1 : 0);
    let dy = (Input.isDown('KeyS') ? 1 : 0) - (Input.isDown('KeyW') ? 1 : 0);
    const len = Math.hypot(dx, dy);
    if (len > 0) {
      const spd = this.speed * (Input.isDown('ShiftLeft') || Input.isDown('ShiftRight') ? this.sprintMult : 1);
      this.x += (dx / len) * spd * dt;
      this.y += (dy / len) * spd * dt;
    }
    this.x = Utils.clamp(this.x, this.radius, WORLD.w - this.radius);
    this.y = Utils.clamp(this.y, this.radius, WORLD.h - this.radius);
    obstacles.forEach(o => Utils.pushOutOfRect(this, o));

    // Aim at mouse
    this.angle = Math.atan2(mouseWorld.y - this.y, mouseWorld.x - this.x);

    // Weapon
    this.weapon.update(dt);
    if (Input.wasPressed('KeyR')) this.weapon.startReload();
    if (Input.mouse.down) {
      const muzzle = this.radius + 14;
      bullets.push(...this.weapon.tryShoot(
        this.x + Math.cos(this.angle) * muzzle, this.y + Math.sin(this.angle) * muzzle, this.angle));
    }
    this.hurtFlash = Math.max(0, this.hurtFlash - dt);
  }

  takeDamage(amount) {
    if (this.dead) return;
    this.health = Math.max(0, this.health - amount);
    this.hurtFlash = 0.25;
  }

  draw(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.beginPath(); ctx.ellipse(3, 5, this.radius, this.radius * .8, 0, 0, 7); ctx.fill();
    ctx.rotate(this.angle);
    ctx.fillStyle = '#2f3a2c'; ctx.fillRect(4, -4, 26, 8);           // gun
    ctx.fillStyle = this.hurtFlash > 0 ? '#e25b4a' : '#5d7a4f';       // body
    ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, 7); ctx.fill();
    ctx.fillStyle = '#d2b48c'; ctx.beginPath(); ctx.arc(2, 0, 7, 0, 7); ctx.fill(); // head
    ctx.restore();
  }
}
